/*-
 * See the file LICENSE for redistribution information.
 *
 * Copyright (c) 2001-2003
 *	Sleepycat Software.  All rights reserved.
 *
 * $Id: fop.h,v 11.4 2003/01/08 04:31:47 bostic Exp $
 */

#ifndef	_FOP_H_
#define	_FOP_H_

#include "dbinc_auto/fileops_auto.h"
#include "dbinc_auto/fileops_ext.h"

#endif /* !_FOP_H_ */
