/*
 *  -
 *  See the file LICENSE for redistribution information.
 *
 *  Copyright (c) 1997-2004
 *	Sleepycat Software.  All rights reserved.
 *
 *  $Id: DatabaseStats.java,v 1.2 2004/09/28 19:30:37 mjc Exp $
 */
package com.sleepycat.db;

public abstract class DatabaseStats {
	// no public constructor
	protected DatabaseStats() {}
}
